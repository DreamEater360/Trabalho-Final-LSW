export class File{
    constructor(name){
        this.name = name
        this.content = ''
    }
}