# Sylas web

## What this?

The sylas web is a simple sistem operation for browser. Your funcion is be a simple prototype for the class: "configuration and manage of changes".

## Who can to use?

It has done to all people what wish simplify yours works in desktops, mighting to acess your progress in any computer.
